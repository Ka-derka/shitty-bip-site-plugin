function matchesTargetDomain(url) {
  try {
    const u = new URL(url);
    const host = u.hostname;
    return host === "gov.pl" || host.endsWith(".gov") || host.endsWith(".gov.pl");
  } catch (e) {
    return false;
  }
}

chrome.webRequest.onCompleted.addListener((details) => {
  if (details.statusCode >= 400 && matchesTargetDomain(details.url)) {
    openVideoWindow();
  }
}, { urls: ["<all_urls>"] });

chrome.webRequest.onErrorOccurred.addListener((details) => {
  if (matchesTargetDomain(details.url)) {
    openVideoWindow();
  }
}, { urls: ["<all_urls>"] });

function openVideoWindow() {
  chrome.windows.create({
    url: chrome.runtime.getURL("video.html"),
    type: "popup",
    width: 800,
    height: 600
  });
}